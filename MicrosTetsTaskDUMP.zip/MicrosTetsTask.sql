-- --------------------------------------------------------
-- Хост:                         localhost
-- Версия сервера:               5.5.50 - MySQL Community Server (GPL)
-- ОС Сервера:                   Win32
-- HeidiSQL Версия:              9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Дамп структуры базы данных MicrosTestTask
CREATE DATABASE IF NOT EXISTS `microstesttask` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `MicrosTestTask`;


-- Дамп структуры для таблица MicrosTestTask.admin
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(50) DEFAULT '0',
  `role_id` int(11) DEFAULT '0',
  `lastName` varchar(50) DEFAULT '0',
  `phone` varchar(50) DEFAULT '0',
  `email` varchar(50) DEFAULT '0',
  `userName` varchar(50) DEFAULT '0',
  `password` varchar(600) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_admin_role` (`role_id`),
  CONSTRAINT `FK_admin_role` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы MicrosTestTask.admin: ~1 rows (приблизительно)
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`id`, `firstName`, `role_id`, `lastName`, `phone`, `email`, `userName`, `password`) VALUES
	(2, 'Asilbek', 3, 'Khamzaev', '+99894-567-77-76', 'asilbekkhamzaev@gmail.com', 'MasterWestt', '$2y$13$32NLjzGSOoOz4qFEeJiO/OXC4DFBubEPLGSUheKsghpimnrM/0CN2');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;


-- Дамп структуры для таблица MicrosTestTask.IncomeCategory
CREATE TABLE IF NOT EXISTS `IncomeCategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `incomeCategory` varchar(50) NOT NULL DEFAULT '0',
  `description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы MicrosTestTask.IncomeCategory: ~1 rows (приблизительно)
/*!40000 ALTER TABLE `IncomeCategory` DISABLE KEYS */;
INSERT INTO `IncomeCategory` (`id`, `incomeCategory`, `description`) VALUES
	(2, 'Зарплата', '');
/*!40000 ALTER TABLE `IncomeCategory` ENABLE KEYS */;


-- Дамп структуры для таблица MicrosTestTask.incomeOperation
CREATE TABLE IF NOT EXISTS `incomeOperation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `incomeShortTitle` varchar(50) DEFAULT '0',
  `incomeCash` float NOT NULL DEFAULT '0',
  `incomeCard` float NOT NULL DEFAULT '0',
  `incomeTotal` float NOT NULL DEFAULT '0',
  `incomeDetail` varchar(500) DEFAULT NULL,
  `incomeCategory_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_incomeOperation_IncomeCategory` (`incomeCategory_id`),
  KEY `FK_incomeOperation_user` (`user_id`),
  CONSTRAINT `FK_incomeOperation_IncomeCategory` FOREIGN KEY (`incomeCategory_id`) REFERENCES `IncomeCategory` (`id`),
  CONSTRAINT `FK_incomeOperation_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы MicrosTestTask.incomeOperation: ~4 rows (приблизительно)
/*!40000 ALTER TABLE `incomeOperation` DISABLE KEYS */;
INSERT INTO `incomeOperation` (`id`, `date`, `incomeShortTitle`, `incomeCash`, `incomeCard`, `incomeTotal`, `incomeDetail`, `incomeCategory_id`, `user_id`) VALUES
	(1, '2019-01-11', 'Зарплата', 1500000, 500000, 2000000, 'Дали месячную зарплату', 2, 1),
	(2, '2019-01-11', 'Зарплата Сына', 500000, 0, 500000, '', 2, 1),
	(4, '2019-01-14', '', 100000, 0, 100000, '', 2, 1),
	(5, '2019-01-15', '', 405500, 0, 405500, '', 2, 1);
/*!40000 ALTER TABLE `incomeOperation` ENABLE KEYS */;


-- Дамп структуры для таблица MicrosTestTask.outcomeCategory
CREATE TABLE IF NOT EXISTS `outcomeCategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `outcomeCategory` varchar(50) NOT NULL DEFAULT '0',
  `description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы MicrosTestTask.outcomeCategory: ~2 rows (приблизительно)
/*!40000 ALTER TABLE `outcomeCategory` DISABLE KEYS */;
INSERT INTO `outcomeCategory` (`id`, `outcomeCategory`, `description`) VALUES
	(2, 'Продукты', ''),
	(3, 'Колледж', NULL);
/*!40000 ALTER TABLE `outcomeCategory` ENABLE KEYS */;


-- Дамп структуры для таблица MicrosTestTask.outcomeOperation
CREATE TABLE IF NOT EXISTS `outcomeOperation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `outcomeShortTitle` varchar(50) DEFAULT NULL,
  `outcomeCash` float NOT NULL DEFAULT '0',
  `outcomeCard` float NOT NULL DEFAULT '0',
  `outcomeTotal` float NOT NULL DEFAULT '0',
  `outcomeDetail` varchar(500) DEFAULT '0',
  `outcomeCategory_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_outcomeOperation_outcomeCategory` (`outcomeCategory_id`),
  KEY `FK_outcomeOperation_user` (`user_id`),
  CONSTRAINT `FK_outcomeOperation_outcomeCategory` FOREIGN KEY (`outcomeCategory_id`) REFERENCES `outcomeCategory` (`id`),
  CONSTRAINT `FK_outcomeOperation_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы MicrosTestTask.outcomeOperation: ~3 rows (приблизительно)
/*!40000 ALTER TABLE `outcomeOperation` DISABLE KEYS */;
INSERT INTO `outcomeOperation` (`id`, `date`, `outcomeShortTitle`, `outcomeCash`, `outcomeCard`, `outcomeTotal`, `outcomeDetail`, `outcomeCategory_id`, `user_id`) VALUES
	(1, '2019-01-11', 'Приставка', 2700000, 300000, 3000000, '', 2, 1),
	(2, '2019-01-12', '', 5000, 0, 5000, '', 2, 1),
	(3, '2019-01-14', 'На сижку', 500, 0, 500, '', 2, 3);
/*!40000 ALTER TABLE `outcomeOperation` ENABLE KEYS */;


-- Дамп структуры для таблица MicrosTestTask.role
CREATE TABLE IF NOT EXISTS `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roleName` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roleName` (`roleName`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы MicrosTestTask.role: ~2 rows (приблизительно)
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` (`id`, `roleName`) VALUES
	(3, 'admin'),
	(4, 'user');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;


-- Дамп структуры для таблица MicrosTestTask.total
CREATE TABLE IF NOT EXISTS `total` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `totalCash` float NOT NULL DEFAULT '0',
  `totalCard` float NOT NULL DEFAULT '0',
  `total` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы MicrosTestTask.total: ~1 rows (приблизительно)
/*!40000 ALTER TABLE `total` DISABLE KEYS */;
INSERT INTO `total` (`id`, `totalCash`, `totalCard`, `total`) VALUES
	(2, -200000, 200000, 0);
/*!40000 ALTER TABLE `total` ENABLE KEYS */;


-- Дамп структуры для таблица MicrosTestTask.user
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) DEFAULT '0',
  `username` varchar(50) NOT NULL DEFAULT '0',
  `auth_key` varchar(32) NOT NULL DEFAULT '0',
  `password_hash` varchar(500) NOT NULL DEFAULT '0',
  `password_reset_token` varchar(500) NOT NULL DEFAULT '0',
  `email` varchar(50) NOT NULL DEFAULT '0',
  `status` smallint(6) NOT NULL DEFAULT '0',
  `role_id` int(11) NOT NULL DEFAULT '0',
  `created_at` int(11) NOT NULL DEFAULT '0',
  `updated_at` int(11) NOT NULL DEFAULT '0',
  `firstName` varchar(50) DEFAULT NULL,
  `lastName` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_user_role` (`role_id`),
  CONSTRAINT `FK_user_role` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы MicrosTestTask.user: ~4 rows (приблизительно)
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`id`, `userID`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `status`, `role_id`, `created_at`, `updated_at`, `firstName`, `lastName`, `phone`) VALUES
	(1, 2, 'MasterWestt', 'z1P7EUemQizqrdHXaQorfvOKibkDiWpw', '$2y$13$32NLjzGSOoOz4qFEeJiO/OXC4DFBubEPLGSUheKsghpimnrM/0CN2', '0', 'asilbekkhamzaev@gmail.com', 10, 3, 1546622156, 1546622156, 'Asilbek', 'Khamzaev', '+998945677776'),
	(3, 0, 'kolya', '0', '$2y$13$0Kw0uUqttUSEHGTkfqcyk.v1Wuh/D2wMfFgJGj5tkaTAWgCs5.45u', '0', '', 10, 4, 1546954721, 1547637419, 'Nikolay', 'Borshov', ''),
	(4, 0, 'lulya', '0', '$2y$13$eS21mVSvhaHyH2DhAjvTFO6LY6labks.XS8NhO426m4jX90yE5XH.', '0', '', 10, 4, 1546954778, 1547013599, 'Lolya', 'Borshova', '+998931234567');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
